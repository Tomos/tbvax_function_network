rm(list=ls())
require(tbvax)

paths = set.paths(countries   = "countries", countrycode = "ZAF", xml = "SIR.xml")
output=run(paths,write.to.file = T)

paths = set.paths(countries   = "countries", countrycode = "ZAF", xml = "SEIR-SES.xml")
output=run(paths,write.to.file = T)

paths = set.paths(countries   = "countries", countrycode = "ZAF", xml = "SEIR-SES-Iinci.xml")
output=run(paths,write.to.file = T)



